# Luna — versão inicial

Primeira etapa: app Android com painel dos 8 relés e firmware ESP32 para controle local.

## Ligação

| Módulo 8 relés | ESP32 |
|---|---|
| IN1…IN8 | GPIO 13, 14, 16, 17, 18, 19, 21, 22 |
| GND | GND comum |
| VCC | Fonte externa 5 V |

O firmware começa criando a rede Wi‑Fi `Luna Casa` com senha `luna-casa-2026`. **Troque essa senha antes de uso real.** Conecte o celular nela e abra `192.168.4.1/api/v1/status` para verificar a ESP32.

Para o teste de um relé: `POST /api/v1/relay` com JSON `{"relay":1,"action":"on"}`.

## Compilação

- Android: abra a pasta `Luna` no Android Studio, sincronize e use `Build > Build APK(s)`.
- ESP32: abra `firmware` no PlatformIO e faça Upload.

Use apenas cargas de baixa tensão durante testes. Não use a montagem em papelão/protoboard para rede 127/220 V.
