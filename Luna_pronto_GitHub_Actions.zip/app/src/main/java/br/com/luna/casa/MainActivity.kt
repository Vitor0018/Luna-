package br.com.luna.casa

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private data class Relay(val id: String, var name: String, var room: String, var on: Boolean = false)
private val LunaDark = Color(0xFF0B0D12)
private val LunaPurple = Color(0xFF8B7CFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { LunaApp() } }
}

@Composable
private fun LunaApp() {
    var tab by remember { mutableIntStateOf(0) }
    var connected by remember { mutableStateOf(false) }
    val relays = remember { mutableStateListOf(*Array(8) { i -> Relay("relay_${i + 1}", "Relé ${i + 1}", "Sem cômodo") }) }
    MaterialTheme(colorScheme = darkColorScheme(primary = LunaPurple, background = LunaDark, surface = Color(0xFF171A22))) {
        Scaffold(containerColor = LunaDark, bottomBar = {
            NavigationBar { listOf("Casa", "Luna", "Ajustes").forEachIndexed { index, title ->
                NavigationBarItem(selected = tab == index, onClick = { tab = index }, icon = { Text(if (index == 0) "⌂" else if (index == 1) "◉" else "⚙") }, label = { Text(title) })
            }}
        }) { padding ->
            when (tab) {
                0 -> Home(Modifier.padding(padding), relays, connected) { connected = !connected }
                1 -> LunaTalk(Modifier.padding(padding), relays)
                else -> Settings(Modifier.padding(padding), relays)
            }
        }
    }
}

@Composable private fun Home(modifier: Modifier, relays: MutableList<Relay>, connected: Boolean, onConnection: () -> Unit) {
    LazyColumn(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Luna", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold); Text("Sua casa inteligente", color = Color.LightGray) }
        item { Card { Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Column { Text(if (connected) "ESP32 conectado" else "ESP32 não conectado", fontWeight = FontWeight.Bold); Text(if (connected) "Controle local ativo" else "Toque para modo de demonstração") }; Switch(connected, onCheckedChange = { onConnection() }) } } }
        item { Text("Dispositivos", style = MaterialTheme.typography.titleLarge) }
        items(relays, key = { it.id }) { relay -> RelayCard(relay) }
    }
}

@Composable private fun RelayCard(relay: Relay) {
    var state by remember { mutableStateOf(relay.on) }
    Card { Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Column { Text(relay.name, fontWeight = FontWeight.Bold); Text("${relay.id} • ${relay.room}", color = Color.LightGray) }; Switch(state, onCheckedChange = { state = it; relay.on = it }) } }
}

@Composable private fun LunaTalk(modifier: Modifier, relays: MutableList<Relay>) {
    var command by remember { mutableStateOf("") }; var response by remember { mutableStateOf("Pode dizer. Ex.: ‘ligar relé 1’.") }
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Falar com a Luna", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Card { Text(response, modifier = Modifier.padding(16.dp)) }
        OutlinedTextField(command, { command = it }, Modifier.fillMaxWidth(), label = { Text("Escreva um comando") })
        Button(onClick = { response = LocalCommands.run(command, relays); command = "" }, modifier = Modifier.fillMaxWidth()) { Text("Enviar para Luna") }
        Text("A voz será ativada após a permissão de microfone e integração de reconhecimento local.", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable private fun Settings(modifier: Modifier, relays: MutableList<Relay>) {
    LazyColumn(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Configurações", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text("Versão inicial: controle local de relés") }
        item { Text("Nomes dos relés", style = MaterialTheme.typography.titleMedium) }
        items(relays, key = { it.id }) { relay -> var name by remember { mutableStateOf(relay.name) }; OutlinedTextField(name, { name = it; relay.name = it }, Modifier.fillMaxWidth(), label = { Text(relay.id) }) }
        item { Text("Sensores, OTA, acesso remoto e usuários serão habilitados nas próximas etapas.", color = Color.LightGray, style = MaterialTheme.typography.bodySmall) }
    }
}

private object LocalCommands {
    fun run(raw: String, relays: MutableList<Relay>): String {
        val text = raw.lowercase().trim()
        val number = Regex("(?:rel[eé]|canal)\\s*(\\d)").find(text)?.groupValues?.getOrNull(1)?.toIntOrNull()
        val target = number?.let { relays.getOrNull(it - 1) } ?: relays.firstOrNull { text.contains(it.name.lowercase()) }
        return when {
            target == null -> "Não entendi qual relé. Diga, por exemplo: ligar relé 1."
            text.contains("liga") || text.contains("acende") || text.contains("ativa") -> { target.on = true; "${target.name} ligado." }
            text.contains("desliga") || text.contains("apaga") -> { target.on = false; "${target.name} desligado." }
            text.contains("estado") -> "${target.name} está ${if (target.on) "ligado" else "desligado"}."
            else -> "Posso ligar, desligar ou informar o estado de um relé."
        }
    }
}
