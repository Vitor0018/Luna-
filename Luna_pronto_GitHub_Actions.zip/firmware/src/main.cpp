#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <ArduinoJson.h>

// Luna 0.1 — somente os 8 relés. Confirme o nível lógico no teste inicial.
constexpr bool RELAY_ACTIVE_LOW = false;
const uint8_t RELAY_PINS[8] = {13, 14, 16, 17, 18, 19, 21, 22};
bool relayState[8] = {false, false, false, false, false, false, false, false};
WebServer server(80);

void writeRelay(uint8_t index, bool enabled) {
  if (index >= 8) return;
  relayState[index] = enabled;
  digitalWrite(RELAY_PINS[index], (enabled ^ RELAY_ACTIVE_LOW) ? HIGH : LOW);
}

void statusRoute() {
  JsonDocument doc; doc["name"] = "Luna ESP32"; doc["version"] = "0.1.0"; doc["ip"] = WiFi.localIP().toString();
  JsonArray relays = doc["relays"].to<JsonArray>();
  for (uint8_t i = 0; i < 8; i++) { JsonObject r = relays.add<JsonObject>(); r["id"] = String("relay_") + (i + 1); r["on"] = relayState[i]; }
  String out; serializeJson(doc, out); server.send(200, "application/json", out);
}

void commandRoute() {
  if (!server.hasArg("plain")) { server.send(400, "application/json", "{\"error\":\"body required\"}"); return; }
  JsonDocument doc; if (deserializeJson(doc, server.arg("plain"))) { server.send(400, "application/json", "{\"error\":\"invalid json\"}"); return; }
  int index = doc["relay"] | 0; const char* action = doc["action"] | "";
  if (index < 1 || index > 8) { server.send(400, "application/json", "{\"error\":\"relay 1..8\"}"); return; }
  bool next = strcmp(action, "on") == 0 ? true : strcmp(action, "off") == 0 ? false : !relayState[index - 1];
  writeRelay(index - 1, next); server.send(200, "application/json", next ? "{\"ok\":true,\"on\":true}" : "{\"ok\":true,\"on\":false}");
}

void setup() {
  Serial.begin(115200);
  for (uint8_t i = 0; i < 8; i++) { pinMode(RELAY_PINS[i], OUTPUT); writeRelay(i, false); }
  WiFi.mode(WIFI_AP); WiFi.softAP("Luna Casa", "luna-casa-2026");
  server.on("/api/v1/status", HTTP_GET, statusRoute);
  server.on("/api/v1/relay", HTTP_POST, commandRoute);
  server.onNotFound([] { server.send(404, "application/json", "{\"error\":\"not found\"}"); });
  server.begin(); Serial.println(WiFi.softAPIP());
}
void loop() { server.handleClient(); }
